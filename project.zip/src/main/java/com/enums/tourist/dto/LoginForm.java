package com.enums.tourist.dto;

import lombok.Data;

@Data
public class LoginForm {
	private String loginId;
	private String password;
}
