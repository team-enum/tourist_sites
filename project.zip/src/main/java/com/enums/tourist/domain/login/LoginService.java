package com.enums.tourist.domain.login;

import com.enums.tourist.repository.MemberRepository;

public class LoginService {
	
	private final MemberRepository memberRepository;
	
	public Member login(String loginId, String password) {
		
	}
}
